from django.apps import AppConfig


class FypblogConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'fypblog'
